# Website
It contains complete code of EMI Bharo Website. It is coded by three undergrad students named Farhan, Saurbh and Devraj.


### Website is live, visit: https://www.emibharo.com/
